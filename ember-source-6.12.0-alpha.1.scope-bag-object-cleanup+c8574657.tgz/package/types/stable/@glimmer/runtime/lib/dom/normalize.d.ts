declare module '@glimmer/runtime/lib/dom/normalize' {
    import type { Indexable, SimpleDocumentFragment, SimpleNode } from "@glimmer/interfaces";
    export interface SafeString {
        toHTML(): string;
    }
    export type Insertion = CautiousInsertion | TrustingInsertion;
    export type CautiousInsertion = string | SafeString | SimpleNode;
    export type TrustingInsertion = string | SimpleNode;
    export function normalizeStringValue(value: unknown): string;
    export function normalizeTrustedValue(value: unknown): TrustingInsertion;
    export function shouldCoerce(value: unknown): value is string | number | boolean | null | undefined;
    export function isEmpty(value: unknown): boolean;
    export function isIndexable(value: unknown): value is Indexable;
    export function isSafeString(value: unknown): value is SafeString;
    export function isNode(value: unknown): value is SimpleNode;
    export function isFragment(value: unknown): value is SimpleDocumentFragment;
    export function isString(value: unknown): value is string;
}