declare module '@glimmer/compiler/lib/passes/1-normalization/visitors/element/classified' {
    import { ASTv2 } from "@glimmer/syntax";
    import type { NormalizationState } from "@glimmer/compiler/lib/passes/1-normalization/context";
    import { Result } from "@glimmer/compiler/lib/shared/result";
    import * as mir from "@glimmer/compiler/lib/passes/2-encoding/mir";
    export type ValidAttr = mir.StaticAttr | mir.DynamicAttr | mir.SplatAttr;
    export interface Classified {
        readonly dynamicFeatures: boolean;
        arg(attr: ASTv2.AttrNode, classified: ClassifiedElement): Result<mir.NamedArgument>;
        toStatement(classified: ClassifiedElement, prepared: PreparedArgs): Result<mir.Statement>;
    }
    export class ClassifiedElement {
        readonly element: ASTv2.ElementNode;
        readonly state: NormalizationState;
        readonly delegate: Classified;
        constructor(element: ASTv2.ElementNode, delegate: Classified, state: NormalizationState);
        toStatement(): Result<mir.Statement>;
        private attr;
        private modifier;
        private attrs;
        private prepare;
    }
    export interface PreparedArgs {
        args: mir.NamedArguments;
        params: mir.ElementParameters;
    }
    export function hasDynamicFeatures({ attrs, modifiers, }: Pick<ASTv2.ElementNode, "attrs" | "modifiers">): boolean;
}