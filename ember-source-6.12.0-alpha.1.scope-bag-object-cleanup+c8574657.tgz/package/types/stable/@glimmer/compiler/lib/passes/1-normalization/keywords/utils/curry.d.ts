declare module '@glimmer/compiler/lib/passes/1-normalization/keywords/utils/curry' {
    import type { CurriedType } from "@glimmer/interfaces";
    import { ASTv2 } from "@glimmer/syntax";
    import type { NormalizationState } from "@glimmer/compiler/lib/passes/1-normalization/context";
    import type { KeywordDelegate } from "@glimmer/compiler/lib/passes/1-normalization/keywords/impl";
    import { Result } from "@glimmer/compiler/lib/shared/result";
    import * as mir from "@glimmer/compiler/lib/passes/2-encoding/mir";
    export function assertCurryKeyword(curriedType: CurriedType): (node: ASTv2.AppendContent | ASTv2.InvokeBlock | ASTv2.CallExpression, state: NormalizationState) => Result<{
        definition: ASTv2.ExpressionNode;
        args: ASTv2.Args;
    }>;
    export function curryKeyword(curriedType: CurriedType): KeywordDelegate<ASTv2.CallExpression | ASTv2.AppendContent, {
        definition: ASTv2.ExpressionNode;
        args: ASTv2.Args;
    }, mir.Curry>;
}