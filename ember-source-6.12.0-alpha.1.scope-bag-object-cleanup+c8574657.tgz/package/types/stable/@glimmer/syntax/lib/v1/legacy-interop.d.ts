declare module '@glimmer/syntax/lib/v1/legacy-interop' {
    import type * as ASTv1 from "@glimmer/syntax/lib/v1/nodes-v1";
    export type MustacheStatementParams = Omit<ASTv1.MustacheStatement, "type" | "escaped">;
    export function buildLegacyMustache({ path, params, hash, trusting, strip, loc, }: MustacheStatementParams): ASTv1.MustacheStatement;
    export type PathExpressionParams = Omit<ASTv1.MinimalPathExpression, "type">;
    export function buildLegacyPath({ head, tail, loc }: PathExpressionParams): ASTv1.PathExpression;
    export function buildLegacyLiteral<T extends ASTv1.Literal>(
        { type, value, loc, }: {
            type: T["type"];
            value: T["value"];
            loc: T["loc"];
        }
    ): T;
}