declare module '@glimmer/syntax/lib/v1/parser-builders' {
    import type { Nullable, Optional, PresentArray } from "@glimmer/interfaces";
    import type * as ASTv1 from "@glimmer/syntax/lib/v1/api";
    import { SourceSpan } from "@glimmer/syntax/lib/source/span";
    /**
     * The Parser Builder differentiates from the public builder API by:
     *
     * 1. Offering fewer different ways to instantiate nodes
     * 2. Mandating source locations
     */
    class Builders {
        pos({ line, column }: {
            line: number;
            column: number;
        }): {
            line: number;
            column: number;
        };
        blockItself({ body, params, chained, loc, }: {
            body: ASTv1.Statement[];
            params: ASTv1.VarHead[];
            chained?: Optional<boolean>;
            loc: SourceSpan;
        }): ASTv1.Block;
        template({ body, blockParams, loc, }: {
            body: ASTv1.Statement[];
            blockParams: string[];
            loc: SourceSpan;
        }): ASTv1.Template;
        mustache({ path, params, hash, trusting, loc, strip, }: {
            path: ASTv1.Expression;
            params: ASTv1.Expression[];
            hash: ASTv1.Hash;
            trusting: boolean;
            loc: SourceSpan;
            strip?: Optional<ASTv1.StripFlags>;
        }): ASTv1.MustacheStatement;
        block({ path, params, hash, defaultBlock, elseBlock, loc, openStrip, inverseStrip, closeStrip, }: {
            path: ASTv1.PathExpression | ASTv1.SubExpression;
            params: ASTv1.Expression[];
            hash: ASTv1.Hash;
            defaultBlock: ASTv1.Block;
            elseBlock: Nullable<ASTv1.Block>;
            loc: SourceSpan;
            openStrip?: Optional<ASTv1.StripFlags>;
            inverseStrip?: Optional<ASTv1.StripFlags>;
            closeStrip?: Optional<ASTv1.StripFlags>;
        }): ASTv1.BlockStatement;
        comment({ value, loc }: {
            value: string;
            loc: SourceSpan;
        }): ASTv1.CommentStatement;
        mustacheComment({ value, loc, }: {
            value: string;
            loc: SourceSpan;
        }): ASTv1.MustacheCommentStatement;
        concat({ parts, loc, }: {
            parts: PresentArray<ASTv1.TextNode | ASTv1.MustacheStatement>;
            loc: SourceSpan;
        }): ASTv1.ConcatStatement;
        element({ path, selfClosing, attributes, modifiers, params, comments, children, openTag, closeTag, loc, }: {
            path: ASTv1.PathExpression;
            selfClosing: boolean;
            attributes: ASTv1.AttrNode[];
            modifiers: ASTv1.ElementModifierStatement[];
            params: ASTv1.VarHead[];
            children: ASTv1.Statement[];
            comments: ASTv1.MustacheCommentStatement[];
            openTag: SourceSpan;
            closeTag: Nullable<SourceSpan>;
            loc: SourceSpan;
        }): ASTv1.ElementNode;
        elementModifier({ path, params, hash, loc, }: {
            path: ASTv1.PathExpression | ASTv1.SubExpression;
            params: ASTv1.Expression[];
            hash: ASTv1.Hash;
            loc: SourceSpan;
        }): ASTv1.ElementModifierStatement;
        attr({ name, value, loc, }: {
            name: string;
            value: ASTv1.AttrNode["value"];
            loc: SourceSpan;
        }): ASTv1.AttrNode;
        text({ chars, loc }: {
            chars: string;
            loc: SourceSpan;
        }): ASTv1.TextNode;
        sexpr({ path, params, hash, loc, }: {
            path: ASTv1.PathExpression | ASTv1.SubExpression;
            params: ASTv1.Expression[];
            hash: ASTv1.Hash;
            loc: SourceSpan;
        }): ASTv1.SubExpression;
        path({ head, tail, loc, }: {
            head: ASTv1.PathHead;
            tail: string[];
            loc: SourceSpan;
        }): ASTv1.PathExpression;
        head({ original, loc }: {
            original: string;
            loc: SourceSpan;
        }): ASTv1.PathHead;
        this({ loc }: {
            loc: SourceSpan;
        }): ASTv1.ThisHead;
        atName({ name, loc }: {
            name: string;
            loc: SourceSpan;
        }): ASTv1.AtHead;
        var({ name, loc }: {
            name: string;
            loc: SourceSpan;
        }): ASTv1.VarHead;
        hash({ pairs, loc }: {
            pairs: ASTv1.HashPair[];
            loc: SourceSpan;
        }): ASTv1.Hash;
        pair({ key, value, loc, }: {
            key: string;
            value: ASTv1.Expression;
            loc: SourceSpan;
        }): ASTv1.HashPair;
        literal<T extends ASTv1.Literal>({ type, value, loc, }: {
            type: T["type"];
            value: T["value"];
            loc: SourceSpan;
        }): T;
    }
    const b: Builders;
    export default b;
}