declare module '@glimmer/util/lib/debug-steps' {
    export let beginTestSteps: (() => void) | undefined;
    export let endTestSteps: (() => void) | undefined;
    export let verifySteps: ((type: string, steps: unknown[] | ((steps: unknown[]) => void), message?: string) => void) | undefined;
    export let logStep: ((type: string, steps: unknown) => void) | undefined;
}