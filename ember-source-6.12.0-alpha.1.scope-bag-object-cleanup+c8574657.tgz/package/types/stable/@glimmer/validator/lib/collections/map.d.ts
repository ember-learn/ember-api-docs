declare module '@glimmer/validator/lib/collections/map' {
    export function trackedMap<Key = unknown, Value = unknown>(
        data?: Map<Key, Value> | Iterable<readonly [Key, Value]> | readonly (readonly [Key, Value])[] | null,
        options?: {
            equals?: (a: Value, b: Value) => boolean;
            description?: string;
        }
    ): Map<Key, Value>;
}