declare module '@glimmer/interfaces/lib/managers/internal' {
    export type * from "@glimmer/interfaces/lib/managers/internal/component.js";
    export type * from "@glimmer/interfaces/lib/managers/internal/helper.js";
    export type * from "@glimmer/interfaces/lib/managers/internal/modifier.js";
}