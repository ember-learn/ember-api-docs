declare module '@ember/template-compilation' {
    import type { TemplateFactory } from "@glimmer/interfaces";
    import type * as ETC from "ember-template-compiler";
    interface PrecompileTemplate {
        (templateString: string, options?: {
            strictMode?: boolean;
            scope?: () => Record<string, unknown>;
            moduleName?: string;
        }): TemplateFactory;
    }
    export let __emberTemplateCompiler: undefined | typeof ETC;
    export const compileTemplate: typeof ETC.compile;
    export let precompileTemplate: PrecompileTemplate;
    export function __registerTemplateCompiler(c: typeof ETC): void;
    export {};
}