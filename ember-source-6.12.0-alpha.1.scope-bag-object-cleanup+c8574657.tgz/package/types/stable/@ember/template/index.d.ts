declare module '@ember/template' {
    export { isTrustedHTML, trustHTML, htmlSafe, isHTMLSafe, type SafeString, type TrustedHTML, } from "@ember/-internals/glimmer";
}