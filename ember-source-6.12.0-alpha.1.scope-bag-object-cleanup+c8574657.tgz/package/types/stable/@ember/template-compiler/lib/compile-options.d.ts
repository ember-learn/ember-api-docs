declare module '@ember/template-compiler/lib/compile-options' {
    import type { EmberPrecompileOptions } from "@ember/template-compiler/lib/types";
    export default function compileOptions(_options?: Partial<EmberPrecompileOptions>): EmberPrecompileOptions;
}